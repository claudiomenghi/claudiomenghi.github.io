clear
close all
currentFigure=figure
title('SatEx (Without Unc)')

timemodels=csvread('models.csv',1,1,[1 1 4 1]);
exp2thzerotime=csvread('Exp2ThresholdZero.csv',1,9,[1 9 4 9]);

exp2thonetime=csvread('Exp2ThresholdOne.csv',1,9,[1 9 4 9]);


subplot(1,3,1)
boxplot(timemodels)
fontsize=25;
fontsizeax=14;

set(gca,'XTick',[])
a = get(gca,'YTickLabel');
set(gca,'YTickLabel',a,'FontName','Times','fontsize',fontsizeax)
xlabel({'$M$', ''},'interpreter', 'latex','FontSize', fontsize)
ylabel('Time (s)','FontSize', fontsize);
hold on
plot(mean(timemodels),  'dk','Marker','*','MarkerSize',10,'LineWidth',2)

subplot(1,3,2)
boxplot(exp2thzerotime)
set(gca,'XTick',[])
a = get(gca,'YTickLabel');
set(gca,'YTickLabel',a,'FontName','Times','fontsize',fontsizeax)
xlabel({'$M+M_\varphi$','$threshold=0$'},'interpreter', 'latex','FontSize', fontsize)

hold on
plot(mean(exp2thzerotime),  'dk','Marker','*','MarkerSize',10,'LineWidth',2)
subplot(1,3,3)
boxplot(round(exp2thonetime))
%ytickformat('%.4d')
yt = get(gca,'YTick');
set(gca,'XTick',[])

%set(gca,'YTickLabel',  cellstr(num2str(yt(:))))
%set(gca,'YTickLabel',a,'FontName','Times','fontsize',fontsizeax)
a = get(gca,'YTickLabel');
set(gca,'YTickLabel',a,'FontName','Times','fontsize',fontsizeax)
xlabel({'$M+M_\varphi$','$threshold=1$'},'interpreter', 'latex','FontSize', fontsize)

h=suptitle('(b) SatEx (Without Unc)')
set(h,'FontSize',fontsize,'FontWeight','normal')

hold on
plot(mean(exp2thonetime),  'dk','Marker','*','MarkerSize',10,'LineWidth',2)
set(currentFigure, 'Position', [0 0 600 400])
a = get(gca,'YTickLabel');
print('EXP2','-depsc')

disp('average model execution')
mean(timemodels)
disp('average zero threshold')
mean(exp2thzerotime)
disp('average one threshold')
mean(exp2thonetime)


disp('saving percentage')
(mean(timemodels)-mean(exp2thzerotime))/mean(timemodels)*100

disp('saving minues')
(mean(timemodels)-mean(exp2thzerotime))/60

disp('overhead percentage')
(mean(exp2thonetime)-mean(timemodels))/mean(timemodels)*100

disp('overhead minues')
(mean(exp2thonetime)-mean(timemodels))/60


