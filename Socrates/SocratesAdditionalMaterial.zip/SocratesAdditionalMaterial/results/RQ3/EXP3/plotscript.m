close all
currentFigure=figure
title('SatEx (With Unc)')

timemodels=csvread('models.csv',1,1,[1 1 4 1]);
exp3thzerotime=csvread('Exp3ThresholdZero.csv',1,2,[1 2 4 2]);

exp3thonetime=csvread('Exp3ThresholdOne.csv',1,2,[1 2 4 2]);


subplot(1,3,1)
boxplot(timemodels)
fontsize=25;
fontsizeax=14;

set(gca,'XTick',[])
a = get(gca,'YTickLabel');
set(gca,'YTickLabel',a,'FontName','Times','fontsize',fontsizeax)
xlabel({'$M$', ''},'interpreter', 'latex','FontSize', fontsize)
ylabel('Time (s)','FontSize', fontsize);


hold on
plot(mean(timemodels),'dk','Marker','*','MarkerSize',10,'LineWidth',2)

subplot(1,3,2)
boxplot(exp3thzerotime)
set(gca,'XTick',[])
a = get(gca,'YTickLabel');
set(gca,'YTickLabel',a,'FontName','Times','fontsize',fontsizeax)
xlabel({'$M+M_\varphi$','$threshold=0$'},'interpreter', 'latex','FontSize', fontsize)


hold on
plot(mean(exp3thzerotime),'dk','Marker','*','MarkerSize',10,'LineWidth',2)
subplot(1,3,3)
boxplot(round(exp3thonetime))
%ytickformat('%.4d')
yt = get(gca,'YTick');
set(gca,'XTick',[])
set(gca,'YTickLabel',  cellstr(num2str(yt(:))))
%set(gca,'YTickLabel',a,'FontName','Times','fontsize',fontsizeax)
%a = get(gca,'YTickLabel');
%set(gca,'YTickLabel',a,'FontName','Times','fontsize',fontsizeax)
a = get(gca,'YTickLabel');
set(gca,'YTickLabel',a,'FontName','Times','fontsize',fontsizeax)
hold on
plot(mean(exp3thonetime),'dk','Marker','*','MarkerSize',10,'LineWidth',2)

xlabel({'$M+M_\varphi$','$threshold=1$'},'interpreter', 'latex','FontSize', fontsize)

h=suptitle('(c) SatEx (With Unc)')
set(h,'FontSize',fontsize,'FontWeight','normal')


set(currentFigure, 'Position', [0 0 600 400])
a = get(gca,'YTickLabel');

print('EXP3','-depsc')



disp('average model execution')
mean(timemodels)
disp('average zero threshold')
mean(exp3thzerotime)
disp('average one threshold')
mean(exp3thonetime)


disp('saving percentage')
(mean(timemodels)-mean(exp3thzerotime))/mean(timemodels)*100

disp('saving minues')
(mean(timemodels)-mean(exp3thzerotime))/60

disp('overhead percentage')
(mean(exp3thonetime)-mean(timemodels))/mean(timemodels)*100

disp('overhead minues')
(mean(exp3thonetime)-mean(timemodels))/60

