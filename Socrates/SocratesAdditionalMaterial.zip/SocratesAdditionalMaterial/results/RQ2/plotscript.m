close all
currentFigure=figure('Renderer', 'painters', 'Position', [10 10 900 300])
%title('SatEx (With Unc)')

formulasize=csvread('Stat.csv',1,4,[1 4 97 4]);
blocks=csvread('Stat.csv',1,2,[1 2 97 2]);
connections=csvread('Stat.csv',1,3,[1 3 97 3]);
time=csvread('Stat.csv',1,5,[1 5 97 5]);



subplot(1,3,1)
boxplot(formulasize)
%ylim([0 200])
ylim([0 200])
set(gca,'YTick',0:50:200)
fontsize=25;
fontsizeax=14;

set(gca,'XTick',[])
a = get(gca,'YTickLabel');
set(gca,'YTickLabel',a,'FontName','Times','fontsize',fontsizeax)
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'FontName','Times','fontsize',fontsizeax)


xlabel('$|\varphi|$','interpreter', 'latex','FontSize', fontsize)
ylabel('Number','FontSize', fontsize);
title('RFOL Size','fontsize',fontsizeax)
ax = gca;
ax.FontSize = 20;

hold on
plot(mean(formulasize), 'dk','Marker','*','MarkerSize',10,'LineWidth',2)

subplot(1,3,3)
boxplot(round(time))
ylim([0 20])
set(gca,'YTick',0:5:20)

%ytickformat('%.4d')
yt = get(gca,'YTick');
set(gca,'XTick',[])
set(gca,'YTickLabel',  cellstr(num2str(yt(:))))

%set(gca,'YTickLabel',a,'FontName','Times','fontsize',fontsizeax)
%a = get(gca,'YTickLabel');
%set(gca,'YTickLabel',a,'FontName','Times','fontsize',fontsizeax)


a = get(gca,'YTickLabel');
set(gca,'YTickLabel',a,'FontName','Times','fontsize',fontsizeax)


xlabel('Time','interpreter', 'latex','FontSize', fontsize)
ylabel('Time (ms)','FontSize', fontsize);

title('Oracle Gen. Time')
ax = gca;
ax.FontSize = 20;

hold on
plot(mean(time), 'dk','Marker','*','MarkerSize',10,'LineWidth',2)


subplot(1,3,2)
a = get(gca,'YTickLabel');
set(gca,'YTickLabel',a,'FontName','Times','fontsize',fontsizeax)

a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'FontName','Times','fontsize',fontsizeax)

ylabel('Number','FontSize', fontsize)

h=boxplot([blocks connections])
ylim([0 350])
set(gca,'YTick',0:100:400)
set(gca,'XTick',[])

h=findobj(gca,'type','text'); 
set(h,'Interpreter','tex')
%set(h(1),'Position',get(h(1),'Position')-10); 
%set(h(2),'Position',get(h(2),'Position')-10);
%set(gca,'XTick',1:2)%2 because only exists 2 boxplot
%set(gca,'XTickLabel',{'Blocks','Connection'},'FontSize',20)
%set(findobj(get(h(1), 'parent'), 'type', 'text'), 'fontsize', 30);

%boxplot(connections)
%set(gca,'XTick',[])
a2 = get(gca,'YTickLabel');
set(gca,'YTickLabel',a2,'FontName','Times','fontsize',fontsizeax)
xlabel('\#Blocks  \#Connections','interpreter', 'latex','FontSize', fontsize)

%xlabel('#Blocks','interpreter', 'latex','FontSize', fontsize)

%a2 = get(gca,'XTickLabel');
%set(gca,'XTickLabel',a2,'FontName','Times','fontsize',fontsizeax)


hold on
plot([mean(blocks) mean(connections)], 'dk','Marker','*','MarkerSize',10,'LineWidth',2)
%h=suptitle('(c) SatEx (With Unc)')
%set(h,'FontSize',fontsize,'FontWeight','normal')
%set(gcf, 'Position', get(0, 'Screensize'));

a = get(gca,'YTickLabel');
title('Oracle Size')
ax = gca;
ax.FontSize = 20;

print('RQ2','-depsc')
