Type of System: Continuous
Inputs:

Outputs:
