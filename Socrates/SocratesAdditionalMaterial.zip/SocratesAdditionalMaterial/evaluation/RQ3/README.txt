{\rtf1\ansi\ansicpg1252\cocoartf1561\cocoasubrtf200
{\fonttbl\f0\fswiss\fcharset0 Helvetica;\f1\fmodern\fcharset0 Courier;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\paperw11900\paperh16840\margl1440\margr1440\vieww21600\viewh15240\viewkind0
\pard\tx566\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\pardirnatural\partightenfactor0

\f0\b\fs48 \cf0 Prerequisite\

\b0 \
- Install Matlab/Simulink R2017a.\
- Make sure the following add-Ons are installed:\
	* Aerospace Blockset \
	* Aerospace Toolbox\
- To install an add-On:\
1- HOME > Add-Ons > Get Add-Ons.\
2- Search for add-ons and install it.  \
\

\b Running the test cases\
\

\b0 1- Open Matlab/Simulink\
2- Change the Current Folder to /RQ3.\
3- Click right on the Folder RQ3 : add to Path > Selected Folders and Subfolders.\
4- From the Command Window run the following script: runTestCases()\
\

\b Inputs/ Outputs
\b0 \
\
-10 input test cases are generated for RQ3 experiment. The test cases are under the folder testcases.\
\
- By following the steps aforementioned, the test cases are run on the model Autopilot (the model is under the folder Simulink_Models).  \
\
- The output of this experiment is saved in the file results.csv under /RQ3 with the following data:\
	* Model: the model name\
 	* TestCase: the test case name\
	* Risk: the threshold which takes 0 or -1 \
	* Result: the fitness measure to assess the test results\
	* Time: the simulation time = 4000\
	* simTime: the execution time 
\f1\fs24 \

\f0\fs48 \
\
\
}