 function varargout = autopilot(Operation,tc,pr,name)
% <problem> <Autopilot>
% Autopilot problem contains the parameters and properties specific for
% the Autopilot model. 
% Operations :
% 'init' : returns a verctor PopDec [I11,I12,...,I21,I22,...,Imn] where
% Ii1,..,Iin helps build the input signal i
% 'properties' : sets some properties like the model name and the data needed to build the time vector 
% 'signal' : takes the vector PopDec and builds the signal inputs, returns
% a structure of signals
% 'param' : set the parameters (constants ..) in the system model if any.


 
    switch Operation
        case 'init'
            urangeTurnKmax      = 45;           %Input Turn Knob value 
            urangeTurnKmin      = 0;          %Input Turn Knob  value
            urangeHDGRefmax     = 180;          %Input HDG Ref value 
            urangeHDGRefmin     = -180;         %Input HDG Ref value        
            urangeALTRefmin     = 0;            %Input ALT Ref value 
            urangeALTRefmax     = 100;         %Input ALT Ref value
            urangePitchWmax     = 30;           %Input Pitch wheel value 
            urangePitchWmin     = -30;          %Input Pitch wheel value
            D        = 21; 
            PopDec = rand(1,D);                
           
            for i = 1:9                
                PopDec(:,i) = round(rand);
            end            
            for i = 10:12                 
                PopDec(:,i) = (PopDec(:,i) * (urangeHDGRefmax - urangeHDGRefmin)) + urangeHDGRefmin;  
            end
            for i = 13:15                 
                PopDec(:,i) = (PopDec(:,i) * (urangeTurnKmax - urangeTurnKmin)) + urangeTurnKmin; 
            end
            for i = 16:18                
                PopDec(:,i) = (PopDec(:,i) * (urangeALTRefmax - urangeALTRefmin)) + urangeALTRefmin;  
            end
            for i = 19:21                 
                PopDec(:,i) = (PopDec(:,i) * (urangePitchWmax - urangePitchWmin)) + urangePitchWmin;  
            end
            varargout = {PopDec};

        case 'properties'
            
            pr.model_name= 'Autopilot_Model';
            pr.fc    = 1000;
%             pr.stime = 25;
            varargout = {pr};
            
        case 'signal'
            X = tc;           
            signals=buildsignals(X,pr); 
            varargout = {signals};  
            
         case 'param'
            X = tc;           
            configureParameters(X,name); 
            varargout = {X};  
    end
     
 end

%% set the inputs
 
function var=buildsignals(X,pr)
    

    nbrInputs = 7;
    TimeSteps = 1001;
    t = 0:pr.stime/pr.fc:pr.stime;
%     set_param(model_cs,'StopTime',num2str(stime));
%     var.time = (0:0.025:25)';
    var.time = t';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    Signals building 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
    for j = 1:nbrInputs
        var.signals(j).values = ones(TimeSteps,1);
        var.signals(j).dimensions =  1;
    end

        d=1;
        for j = 1:nbrInputs
            i=1;
            while i <= 901
                a=X(1,d);
                a1(i:i+332) = a*ones(1,333);
                i = i + 333;
                d = d+1;
            end
            
            a1(1,1000:1001)= a; 
            var.signals(j).values = a1';

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
        end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    Scenarios: Fixing inputs 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         var.signals(1).values = ones(TimeSteps,1);
%         var.signals(2).values = zeros(TimeSteps,1);
%         var.signals(3).values = zeros(TimeSteps,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %   models = {'roll_ap_rev.slx','yaw_damper_rev.slx','pitch_ap_rev.slx','Autopilot_rev.slx','AP_Lib_rev.slx','Heading_Mode_rev.slx','attitude_controller_rev.slx','Altitude_Mode_rev.slx'};
%    open_system(models);
end
function configureParameters(X,name)
end