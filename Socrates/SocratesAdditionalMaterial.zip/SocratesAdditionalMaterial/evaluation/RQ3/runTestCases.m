% RUNTESTCASES function gets the properties of each model (name, fc , stime) and the generated test inputs in a mat file and
% runs the test case on the model.
% Generates a mat file called 'simResult' 
% Generates result.csv : Model | TestCase | Risk | Result | Time | SimTime
% in problem = {} : put the list of model's problem e.g. problem = {'twotanks','autopilot'}
% in timeSet = {} : put the simulation time values.
 
function runTestCases()
        bdclose
       resultfilename='./results.csv';
       delete resultfilename
        fid = fopen(resultfilename,'w');
        fprintf(fid,'%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n','Model', 'TestCase','Risk', 'Result','Time','SimTime','Req_1_1','Req_1_10_1','Req_1_10_2','Req_1_2','Req_1_3','Req_1_4_1','Req_1_4_2','Req_1_5','Req_1_6','Req_1_7','Req_1_8');
        fclose(fid);
        warning('off','all'); 
        riskValues = [0,-1];
        %% Inputs
%         'twotanks','nl','regulators','euler','eb','tustin','fsm','neural','swim'
%         [10000,100000,200000],[10000,100000,200000],[10000,100000,200000],[10000,100000,200000],[10000,100000,200000],[10000,100000,200000],[1000,2000],[1000,2000],[1000,2000]
        problems = {'autopilot'};
        
        timeSet = {4000};            
        
        Joint = containers.Map(problems,timeSet);

        %riskValues=[-0.3,-0.6,-0.9];

        cd(fileparts(mfilename('fullpath')));
        addpath(genpath(cd));
        now1 = tic();
        for modelindex=1:length(problems)         
            model=problems{modelindex};
            problem = str2func(char(model));
            for st=Joint(char(model))
                pr.stime = st;
                pr=problem('properties',[],pr,[]);
                modelFolderName=erase(pr.model_name,'_Model');
                modelpath = strcat('./Simulink_Models/',modelFolderName,'/');
                addpath(modelpath);
                req_list = dir (strcat(modelpath,'*Req*.m'));

                %% Processing different test cases

                modelName=pr.model_name;
                
                % copies the model from the model_original to a working model version that is used to add the requirements
                originalModelName=strcat(modelpath,modelName,'_original','.slx');
                destinationModelName=strcat(modelpath,modelName,'.slx');
                copyfile(originalModelName,destinationModelName);
                generatedFile=destinationModelName;

                %% Running only the model
                disp(strcat('Running the model: ',pr.model_name));
                [path,name,ext]=fileparts(generatedFile);
                open_system(generatedFile); 

                mat_list = dir (strcat('./testcases/',lower(erase(pr.model_name,'_Model')),'_*_',num2str(st),'.mat'));
                for l = 1: size(mat_list,1)
                    matFileName = erase(mat_list(l).name,'.mat');
                    m = matfile(strcat(matFileName,'.mat'));
                    var = m.testinputs;
                    [path,name,ext]=fileparts(generatedFile);
                    open_system(generatedFile);   
                    testcase = problem('param',var,pr,name);

                    cs = getActiveConfigSet(name);
                    model_cs = cs.copy;
                    t_fin = st;
                    % set the inputs of the model from modelworkspace
                    hws = get_param(name, 'modelworkspace');
                    list = whos;
                    N = length(list);
                    for  n = 1:N
                        hws.assignin(list(n).name,eval(list(n).name));
                    end

                    now = tic();
                    sim(generatedFile, model_cs);
                    exectime = toc(now); 

                    disp("Execution time: "+exectime);
                    close_system(generatedFile,0);

                    fid = fopen(resultfilename,'a');
                    fprintf(fid,'%s,%s,%s,%s,%f,%f,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n',pr.model_name,matFileName,'-','-',pr.stime,exectime,'-','-','-','-','-','-','-','-','-','-','-');
                    fclose(fid);

                end
                %% Adds all the requirements to the model

                for i = 1: size(req_list,1)
                    %disp('***********************');                    
                    requirement_name=erase(req_list(i).name,'.m');
                    %disp(requirement_name);
                    %disp(strcat('Considering the model: ',pr.model_name));
                    %disp(strcat('Considering the requirement: ',requirement_name));
                    %disp(strcat('Adding the requirement ',requirement_name,'to the model: ',pr.model_name));

                    % adds the requirement to the model

                    requirementName=requirement_name;
                    originalModelName=strcat(modelpath,modelName,'.slx');
                    requirementToBeExecuted=strcat(modelpath,requirementName,'.m');
                    open_system(originalModelName);   
                    run(requirementToBeExecuted);

                    %generatedFile=addRequirementToModel(modelpath,pr.model_name,requirement_name);
                end
                for l = 1: size(mat_list,1)
                    matFileName = erase(mat_list(l).name,'.mat');
                    m = matfile(strcat(matFileName,'.mat'));
                    var = m.testinputs;
                    [path,name,ext]=fileparts(generatedFile);
                    open_system(generatedFile);   
                    testcase = problem('param',var,pr,name);
                    %% Processing different risk values
                    for tollerablerisk = riskValues

                        disp(strcat('considering the risk value',num2str(tollerablerisk)));
                        % setting tollerable risk for all the requirements
                        for i = 1: size(req_list,1)
                            requirement_name=erase(req_list(i).name,'.m');
                            set_param(strcat(name,'/tollerablerisk',requirement_name),'Value', num2str(tollerablerisk));
                        end
                        save_system(generatedFile);
                         %disp(strcat("Considering the file: ",generatedFile));

                         % generatedFile without extenstion
                        cs = getActiveConfigSet(name);
                        model_cs = cs.copy;

                        %% Running the model with the requirements
                        disp('Running the model with the requirements');


                        % set the inputs of the model from modelworkspace
                        hws = get_param(name, 'modelworkspace');
                        list = whos;
                        N = length(list);
                        for  n = 1:N
                            hws.assignin(list(n).name,eval(list(n).name));
                        end

                        now = tic();
                        t_fin = st;
                        % saving the simulationResult into simOut
                        simOut=sim(generatedFile, model_cs);
                        exectime = toc(now); 

                        %% Saving the simulation results
                        % saving the simulation Results
                        resultFolderName = strcat(erase(pr.model_name,'_Model'),'_Simulation_Results');
                        mkdir(strcat('Simulation_Results/',resultFolderName,'/'));
                        simResult= strcat('Simulation_Results/',resultFolderName,'/',requirement_name,'_r',num2str(tollerablerisk),'.mat');
                        save (simResult,'simOut');

                        %% Saving time statistics
                        disp("Execution time: "+exectime);

                        obtainedresult=1;
                        reqResults = zeros(1,size(req_list,1));
                        for i = 1: size(req_list,1)
                            requirement_name=erase(req_list(i).name,'.m');
                            outputres=strcat('simOut.result_',requirement_name,'.Data');
                            reqResults(i)=eval(outputres);
                            obtainedresult=min(obtainedresult,eval(outputres));
                        end
                        disp("Result: ");

                        disp(obtainedresult)
                        res=[requirement_name  exectime];

                        outputname = strcat('output_',name,'.mat');
                        %save (outputname);

                        %disp([pr.model_name requirement_name pr.stime exectime obtainedresult])
                        fid = fopen(resultfilename,'a');
                        fprintf(fid,'%s,%s,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f\n',pr.model_name,matFileName,tollerablerisk,obtainedresult,pr.stime,exectime,reqResults);
                        fclose(fid);
                        delete *.slxc
                        delete *.mat

                        disp('***********************');
                    end
                    save_system(generatedFile);
                    close_system(generatedFile);
                end
            end
        end
        disp("Total execution time: ");
        display(toc(now1));
end
