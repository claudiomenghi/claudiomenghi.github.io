function [testinputs]=generateTestCase(n_tc)
% GENERATETESTCASE takes the number of test inputs and generates inputs for
% a given model.
% in problem = {} : put the list of model's problem e.g. problem = {'twotanks','autopilot'}
% in timeSet = {} : put the simulation time values.
% Builds the signal inputs
% Generates a mat file for each test case "modelname_tc_i_time" 
% Generates a csv. file for each model. Each file contains all the test
% cases generated for the model

        problems = {'autopilot'};    
        timeSet = {4000};
        Joint = containers.Map(problems,timeSet);
        cd(fileparts(mfilename('fullpath')));
        addpath(genpath(cd));
            for model=keys(Joint)
                problem = str2func(char(model));
                for n = 1:n_tc
                    for st=Joint(char(model))
                        pr.stime = st;
                        pr=problem('properties',[],pr,[]);
                        tc = problem('init', []);                
                        testinputs = problem('signal',tc,pr,[]);
                        display('Build signals');
                        save(strcat(char(model),'_tc_',num2str(n),'_',num2str(st),'.mat'), 'testinputs');
                    end
                end
            end            
end