RQ1 - contains the encoding of the requirements using the socrates language
RQ2 - contains the results presented in RQ2 which are automatically stored by socrates in the files GeneralStatistics and statistics as the tool is used
RQ3 - contains the script and the results for RQ3
