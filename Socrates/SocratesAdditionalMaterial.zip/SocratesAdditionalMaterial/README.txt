Description of the folders and their content

Appendix.pdf - contains the appendix of the paper

installer - contains the Socrates installation instruction and a DEMO application that can be used to evaluate Socrates

results -  contains the results of the experiments and the scripts used to generate the graphs in the paper for the different RQs and experiments

models - contains the Autopilot, Tustin, Regulator, Neural Network, and Two Tanks models considered in this paper

evaluation - the properties and scripts used in the evaluation
